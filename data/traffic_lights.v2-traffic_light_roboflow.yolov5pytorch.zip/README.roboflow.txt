
traffic_lights - v2 traffic_light_roboflow
==============================

This dataset was exported via roboflow.ai on March 18, 2021 at 7:59 PM GMT

It includes 101 images.
Trafficlights are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


